require 'spec_helper'

describe Notification do
  pending "add some examples to (or delete) #{__FILE__}"
end
