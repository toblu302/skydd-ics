require "snorby/rule"

Snorby::Rule.paths = Snorby::CONFIG[:rules]

