# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Snorby::Application.config.secret_token = 'b5893af7fcebed06c335240b70740caef872c73d18265959d954feddab0a7dc2285e210f4864a23f2572a45a45098c6b11a00b006cf84773340ce32dd7647b50'
