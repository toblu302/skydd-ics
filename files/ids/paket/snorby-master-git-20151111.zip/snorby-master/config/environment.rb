# Load the rails application
require File.expand_path('../application', __FILE__)
Snorby::Application.initialize!
